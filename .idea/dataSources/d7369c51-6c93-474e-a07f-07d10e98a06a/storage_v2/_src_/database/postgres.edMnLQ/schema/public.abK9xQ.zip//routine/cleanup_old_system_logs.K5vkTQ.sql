create function cleanup_old_system_logs() returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM system_logs 
    WHERE timestamp < NOW() - INTERVAL '30 days';
END;
$$;

alter function cleanup_old_system_logs() owner to postgres;

grant execute on function cleanup_old_system_logs() to anon;

grant execute on function cleanup_old_system_logs() to authenticated;

grant execute on function cleanup_old_system_logs() to service_role;

